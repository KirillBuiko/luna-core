

// 1000 - 2000: Data type errors
export enum ResultCode {
    OK = 1,
    FAIL = 2,

    INFO_NOT_GIVEN = 1000,
}
