export type EndpointNames =
    | "generator"
    | "executor"
    | "interpreter"
    | "planner"
    | "variablesStorage"
    | "modulesStorage"
    | "computationModelsStorage"
