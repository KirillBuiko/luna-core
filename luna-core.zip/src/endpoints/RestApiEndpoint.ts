import type {EndpointStatus} from "@/app/types/IEndpoint";
import type {
    MultipartTransferObject,
    NarrowedDestination
} from "@/types/Types";
import type {RemoteStaticEndpointConfigType} from "@/app/types/RemoteStaticEndpointConfigType";
import type {GetInfo__Output} from "@grpc-build/GetInfo";
import type {DataInfo} from "@grpc-build/DataInfo";
import {Endpoint} from "@/endpoints/Endpoint";
import type {ProtocolType} from "@/types/Types";
import FormData from "form-data";
import {PassThrough, Readable} from "node:stream";
import type {ReadableStream} from "stream/web";
import busboy, {Busboy} from "busboy";
import axios from "axios";
import {randomBoundary} from "@/utils/randomBoundary";

type FetchOptions = { url: string, body?: string, contentType?: string }
export type FieldType = { key: string, value: string, contentType?: string }

export class RestApiEndpoint extends Endpoint {
    status: EndpointStatus = "not-connected";
    protocol: ProtocolType = "REST_API";
    config: RemoteStaticEndpointConfigType;

    async init(config: RemoteStaticEndpointConfigType): Promise<Error | null> {
        this.config = config;
        this.status = "connected";
        return null;
    }

    protected getGetHandler(info: GetInfo__Output):
        NarrowedDestination<"REST_API", "GET"> {
        const multipart = this.getMultipart({
            url: `${this.config.host}/get`,
            body: JSON.stringify(info)
        })

        const reader = (async (): Promise<MultipartTransferObject> => {
            const resolvedMultipart = await multipart;
            if (!("info" in resolvedMultipart.fields)) {
                throw "No info in multipart";
            }
            return {
                info: JSON.parse(resolvedMultipart.fields.info),
                data: resolvedMultipart.stream
            }
        })()

        return {
            requestName: "GET",
            protocol: "REST_API",
            destReader: reader
        }
    }

    protected getSetHandler(info: DataInfo):
        NarrowedDestination<"REST_API", "SET"> {
        const {reader, dataWriter} = this.sendMultipart({
            url: `${this.config.host}/set`,
            streamName: "data",
            fields: [
                {key: "info", value: JSON.stringify(info), contentType: "application/json"}
            ]
        })

        const transformedReader = (async () => {
            const resolved = await reader;
            return JSON.parse(resolved);
        })()

        return {
            requestName: "SET",
            protocol: "REST_API",
            destReader: transformedReader,
            destWriter: dataWriter
        }
    }

    async baseFetch<T>(options: FetchOptions): Promise<Response> {
        options.contentType = options.body && (options.contentType || "application/json");
        return fetch(options.url, {
            method: options.body ? "POST" : "GET",
            body: options.body,
            headers: {...(options.contentType ? {'Content-Type': options.contentType} : {})}
        }).catch(err => {
            throw "Endpoint is not available: " + err;
        }).then(async response => {
            if (!response.ok) {
                throw await response.text();
            }
            return response;
        })
    }

    async getFile(options: FetchOptions) {
        return this.baseFetch(options).then(async (response) => {
            return Readable.fromWeb(response.body as ReadableStream);
        })
    }

    async getText(options: FetchOptions) {
        return this.baseFetch(options).then(async (response) => {
            return await response.text();
        })
    }

    async getJson(options: FetchOptions) {
        return this.baseFetch(options).then(async (response) => {
            return await response.json();
        })
    }

    getMultipart(options: FetchOptions) {
        return new Promise<{ fields: Record<string, string>, stream: Readable }>
        (async (resolve, reject) => {
            let response: Response;
            try {
                response = await this.baseFetch(options);
            } catch (e) {
                return reject(e);
            }

            let fields: Record<string, string> = {};
            let stream: Readable;
            let bb: Busboy;

            try {
                bb = busboy({headers: {"content-type": response.headers.get("content-type") ?? undefined}});
                Readable.fromWeb(response.body as ReadableStream).pipe(bb);
            } catch (err) {
                return reject("Multipart handling error: " + err);
            }

            function resolvePromise() {
                resolve({
                    fields,
                    stream
                });
            }

            bb.on("field", (name, value) => {
                fields[name] = value;
            }).on("file", (name, value) => {
                stream = value;
                resolvePromise();
            }).on("error", (err) => {
                reject(err);
            }).on("close", () => {
                resolvePromise();
            });
        })
    }

    sendMultipart(options: { url: string, fields: FieldType[], streamName: string }) {
        const multipartPass = new PassThrough();
        const form = new FormData();
        form.setBoundary(randomBoundary(24, 16));
        options.fields.forEach((f) => {
            form.append(f.key, f.value, {
                contentType: f.contentType
            })
        });
        console.log(form.getLengthSync());
        form.append(options.streamName, multipartPass);
        console.log(form.getBoundary());
        const reader = new Promise<string>((resolve, reject) =>
            form.submit(options.url, (err, res) => {
                if (err) {
                    reject("Endpoint is not available: " + err);
                } else {
                    res.on("data", (data) => {
                        res.statusCode != 200 ? reject(data.toString()) : resolve(data.toString());
                    })
                }
            }))
        return {
            reader,
            dataWriter: multipartPass
        }
    }
}


