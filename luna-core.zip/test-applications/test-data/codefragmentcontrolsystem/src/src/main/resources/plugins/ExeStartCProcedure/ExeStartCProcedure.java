import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import library.Plugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ExeStartCProcedure implements Plugin
{
    @Override
    public List<String> getResult(String id, String urlToControlSystem /*http://localhost:12345/*/)
    {
        JsonNode response = null;
        String exePath = null;
        try
        {
            HttpURLConnection connection = (HttpURLConnection) new URL(urlToControlSystem + "/" + id + "/info?type=full").openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
            {
                builder.append(line);
            }
            reader.close();
            ObjectMapper objectMapper = new ObjectMapper();
            response = objectMapper.readTree(builder.toString());


            connection = (HttpURLConnection) new URL(urlToControlSystem + "/" + id + "/info?specific=EXE_PATH").openConnection();
            connection.setRequestMethod("GET");

            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            builder = new StringBuilder();
            while ((line = reader.readLine()) != null)
            {
                builder.append(line);
            }
            reader.close();
            objectMapper = new ObjectMapper();
            exePath = objectMapper.readTree(builder.toString()).get("EXE_PATH").asText();
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }

        if(response == null)
        {
            System.out.println("Can't get access to controlSystem");
            return new ArrayList<>();
        }

        boolean error = response.get("errorOccurred").asBoolean();
        if(error)
        {
            System.out.println("Error accessing the control system: " + response.asText());
            return new ArrayList<>();
        }

        int inputCount = response.get("input_var_count").asInt();
        int outputCount = response.get("output_var_count").asInt();
        List<String> input_types = new ArrayList<>();
        List<String> output_types = new ArrayList<>();

        JsonNode input = response.get("input_types");
        for(JsonNode node : input)
        {
            String value = node.asText();
            input_types.add(value);
        }
        JsonNode output = response.get("output_types");
        for(JsonNode node : output)
        {
            String value = node.asText();
            output_types.add(value);
        }


        String include = "#include <cstdlib>\n#include <cstring>\n#include <cstdio>\n";
        String name = "exeStartCProcedure";

        StringBuilder main = new StringBuilder();
        StringBuilder mainString = new StringBuilder();
        mainString.append("int ");
        mainString.append("exeStartCProcedure(");

        for(int i = 0; i < inputCount; i++)
        {
            switch(input_types.get(i).split(";")[0])
            {
                case("int"):
                {
                    mainString.append("const int i");
                    mainString.append(i);
                    if(i < inputCount - 1)
                    {
                        mainString.append(",");
                    }
                    else
                    {
                        if(outputCount > 0)
                        {
                            mainString.append(",");
                        }
                    }
                    break;
                }
                case("local_path"):
                case("any_path"):
                {
                    mainString.append("const char* i");
                    mainString.append(i);
                    if(i < inputCount - 1)
                    {
                        mainString.append(",");
                    }
                    else
                    {
                        if(outputCount > 0)
                        {
                            mainString.append(",");
                        }
                    }
                    break;
                }
            }
        }

        for(int i = 0; i < outputCount; i++)
        {
            switch(output_types.get(i).split(";")[0])
            {
                case("int"):
                {
                    mainString.append("int* o");
                    mainString.append(i);
                    if(i < outputCount - 1)
                    {
                        mainString.append(",");
                    }
                    break;
                }
                case("local_path"):
                case("any_path"):
                {
                    mainString.append("char* o");
                    mainString.append(i);
                    if(i < outputCount - 1)
                    {
                        mainString.append(",");
                    }
                    break;
                }
            }
        }
        mainString.append(")");
        main.append(mainString);

        main.append("\n{\n");
        main.append("char exe[2048] = \"./src/");
        main.append(exePath);
        main.append("\";\n");
        for(int i = 0; i < inputCount; i++)
        {
            switch(input_types.get(i).split(";")[0])
            {
                case("int"):
                {
                    main.append("strcat(exe, \" \");\n");
                    main.append("char str");
                    main.append(i);
                    main.append("[25];\n");
                    main.append("sprintf(str");
                    main.append(i);
                    main.append(", \"%d\", i");
                    main.append(i);
                    main.append(");\n");
                    main.append("strcat(exe, str");
                    main.append(i);
                    main.append(");\n");
                    break;
                }
                case("any_path"):
                case("local_path"):
                {
                    main.append("strcat(exe, \" \");\nstrcat(exe, i");
                    main.append(i);
                    main.append(");\n");
                    break;
                }
            }
        }
        main.append("int check = system(exe);\nif(check == 1)\n{\nreturn 1;\n}\n");
        for(int i = 0; i < outputCount; i++)
        {
            switch(output_types.get(i).split(";")[0])
            {
                case("any_path"):
                case("local_path"):
                {
                    String path = output_types.get(i).split(";")[1];
                    main.append("sprintf(o1, \"");
                    main.append(path);
                    main.append("\");\n");
                    break;
                }
            }
        }
        main.append("return 0;\n}\n");

        List<String> result = new ArrayList<>();
        result.add(name);
        result.add(include);
        result.add(main.toString());
        return result;
    }
}