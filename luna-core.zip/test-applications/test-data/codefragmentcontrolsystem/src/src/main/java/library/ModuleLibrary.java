package library;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import library.exceptions.*;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

import static library.Folders.*;

@SpringBootApplication
@RestController
public class ModuleLibrary
{
	private static final Path cDrive = Paths.get("C:/");
	private static final Path folderPath = cDrive.resolve(MAIN_FOLDER);
	private static final Path pluginPath = folderPath.resolve(PLUGINS_FOLDER);
	private static final Path fragmentsPath = folderPath.resolve(FRAGMENTS_FOLDER);

	public static void main(String[] args)
	{
		System.out.println("Starting application...");
		if(initFolders())
		{
			SpringApplication.run(ModuleLibrary.class, args);
		}
	}

	@GetMapping("/{unknownPath}")
	public ResponseEntity<?> handleNotFound(@PathVariable String unknownPath)
	{
		System.out.println("HandleNotFound routing");
		Map<String, Object> errorResponse = new HashMap<>();
		errorResponse.put("errorOccurred", true);
		errorResponse.put("errorMessage","No such method: " + unknownPath + " is implemented");
		errorResponse.put("errorCode", 10);

		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
	}

	@GetMapping(value = "/{className}/{unknownPath}")
	public ResponseEntity<?> handleClassName(@PathVariable String className, @PathVariable String unknownPath)
	{
		System.out.println("Unknown codeFragmentMethod / Code Fragment routing");
		ResponseEntity<Map<String, Object>> list = getCodeFragments();
		List<String> codeFragments = (List<String>)(list.getBody().get("code_fragments"));
		if(!codeFragments.contains(className))
		{
			return ResponseEntity.status(400).body(handleException(new UnknownCodeFragmentException("There is no such code_fragment in the system right now : " + className)));
		}
		else
		{
			return ResponseEntity.status(400).body(handleException(new UnknownCodeFragmentMethodException("There is no such method in the requested code fragment: " + unknownPath)));
		}
	}

	@GetMapping(value = "/code_fragments", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getCodeFragments()
	{
		int count = 0;
		System.out.println("code fragments routing");
		Map<String, Object> resultJson = new HashMap<>();
		ArrayList<String> result = new ArrayList<>();
		try
		{
			if (Files.exists(fragmentsPath))
			{
				Files.walk(fragmentsPath, 1).filter(Files::isDirectory).skip(1).forEach(folder -> result.add(folder.getFileName().normalize().toString()));
				count = (int) Files.walk(fragmentsPath, 1).filter(Files::isDirectory).skip(1).count();
			}
			else
			{
				System.out.println("Fragments folder not found when trying to Files.exists(fragmentsPath)");
				return ResponseEntity.status(500).body(handleException(new WalkingCodeFragmentsFolderException("Fragments folder not found")));
			}
			resultJson.put("code_fragment_count", String.valueOf(count));
			resultJson.put("code_fragments", result);
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
			return ResponseEntity.status(500).body(handleException(new WalkingCodeFragmentsFolderException(e.getMessage())));
		}
		return ResponseEntity.ok(resultJson);
	}

	@GetMapping(value = "/{className}/plugins", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getPluginsFromCodeFragment(@PathVariable String className)
	{
		System.out.println("plugins inside code fragment routing");
		int count = 0;
		Map<String, Object> resultJson = new HashMap<>();
		resultJson = getSpecific(className, "IMPLEMENTED_PLUGINS");
        if(resultJson.get("IMPLEMENTED_PLUGINS") != null)
        {
            String res = resultJson.get("IMPLEMENTED_PLUGINS").toString();
            String[] result = res.split(";");
            resultJson.put("plugins", result);
            resultJson.remove("IMPLEMENTED_PLUGINS");
        }
        else
        {
            return ResponseEntity.status(500).body(handleException(new CantFindSpecificValueException ("Can't find field IMPLEMENTED_PLUGINS in description.")));
        }
		return ResponseEntity.ok(resultJson);
	}

	@GetMapping(value = "/plugins", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity <Map<String, Object>> getPlugins()
	{
		System.out.println("all plugins routing");
		int count = 0;
		Map<String, Object> resultJson = new HashMap<>();
		ArrayList<String> result = new ArrayList<>();
		try
		{
			if (Files.exists(pluginPath))
			{
				Files.walk(pluginPath, 1).filter(Files::isDirectory).skip(1).forEach(folder -> result.add(folder.getFileName().normalize().toString()));
				count = (int) Files.walk(pluginPath, 1).filter(Files::isDirectory).skip(1).count();
			}
			else
			{
				return ResponseEntity.status(500).body(handleException(new PathToPluginFolderException("Plugins folder does not exists")));
			}
			resultJson.put("plugin_count", String.valueOf(count));
			resultJson.put("plugins", result);
		}
		catch(Exception e)
		{
			return ResponseEntity.status(500).body(handleException(new WalkingPluginFoldersException(e.getMessage())));
		}
		return ResponseEntity.ok(resultJson);
	}

	@GetMapping(value = "/{className}/info", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getInfo(@PathVariable String className, @RequestParam(required = false) String type, @RequestParam(required = false) String specific)
	{
		System.out.println("Code fragment info routing");
		ResponseEntity<Map<String, Object>> list = getCodeFragments();
		List<String> codeFragments = (List<String>)(list.getBody().get("code_fragments"));
		if(!codeFragments.contains(className))
		{
			System.out.println("UnknownCodeFragmentException - There is no such code_fragment in the system right now (codeFragments.contains("+ className +"))");
			return ResponseEntity.status(400).body(handleException(new UnknownCodeFragmentException("There is no such code_fragment in the system right now")));
		}

		Map<String, Object> resultMap;

		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode result = objectMapper.createObjectNode();
		if(specific != null)
		{
			JsonNode specificNode = null;
			if(type == null)
			{
				String temp = (String) getSpecific(className, specific).get(specific);
				Map<String, Object> newNode = new HashMap<>();
				newNode.put(specific, temp.split(";")[0]);
				newNode.put("errorOccurred", false);
				specificNode = objectMapper.valueToTree(newNode);

			}
			else if(type.equals("full"))
			{
				specificNode = objectMapper.valueToTree(getSpecific(className, specific));
			}
			if(checkAndAddErrorsToResult(specificNode, result))
			{
				System.out.println("Some errors occurred inside info getting (checkErrors and add to result)");
				return ResponseEntity.status(400).body(objectMapper.convertValue(result, Map.class));
			}
			result.setAll((ObjectNode) specificNode);
			resultMap = objectMapper.convertValue(result, Map.class);
			System.out.println("Successfully returning specific info request");
			return ResponseEntity.ok(resultMap);
		}
		JsonNode inputVarCount = objectMapper.valueToTree(getInputVarCount(className));
		JsonNode outputVarCount = objectMapper.valueToTree(getOutputVarCount(className));
		JsonNode description = objectMapper.valueToTree(getModuleDescription(className));
		JsonNode name = objectMapper.valueToTree(getName(className));
		JsonNode inputVarTypes = objectMapper.valueToTree(getInputVarTypes(className));
		JsonNode inputVarDescriptions = objectMapper.valueToTree(getInputVarDescriptions(className));
		JsonNode outputVarTypes = null;
		if(type == null)
		{
			outputVarTypes = objectMapper.valueToTree(getOutputVarTypesLight(className));
		}
		else if(type.equals("full"))
		{
			outputVarTypes = objectMapper.valueToTree(getOutputVarTypesFull(className));
		}

		JsonNode outputVarDescriptions = objectMapper.valueToTree(getOutputVarDescriptions(className));
		JsonNode implementedPlugins = objectMapper.valueToTree(getImplementedMethods(className));


		if(checkAndAddErrorsToResult(inputVarCount, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(outputVarCount, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(inputVarTypes, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(outputVarTypes, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(inputVarDescriptions, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(outputVarDescriptions, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(name, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(description, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));
		if(checkAndAddErrorsToResult(implementedPlugins, result)) return ResponseEntity.status(500).body(objectMapper.convertValue(result, Map.class));

		result.setAll((ObjectNode) name);
		result.setAll((ObjectNode) description);
		result.setAll((ObjectNode) outputVarDescriptions);
		result.setAll((ObjectNode) inputVarDescriptions);
		result.setAll((ObjectNode) inputVarCount);
		result.setAll((ObjectNode) outputVarCount);
		result.setAll((ObjectNode) inputVarTypes);
		result.setAll((ObjectNode) outputVarTypes);
		result.setAll((ObjectNode) implementedPlugins);

		resultMap = objectMapper.convertValue(result, Map.class);
		return ResponseEntity.ok(resultMap);
	}

	private @ResponseBody Map<String, Object> getSpecific(@PathVariable String className, String key)
	{
		System.out.println("GetSpecific func");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, key);
			if(descriptionValue == null)
			{
				throw new CantFindSpecificValueException("Can't find " + key + " in description file");
			}

			Map<String, Object> result = new HashMap<>();
			result.put(key, descriptionValue);
			result.put("errorOccurred", false);
			System.out.println("GetSpecific func success");
			return result;
		}
		catch (Exception e)
		{
			System.out.println("Exception in getSpecific: " + e.getMessage());
			return handleException(e);
		}
	}

	@PostMapping(value = "/add_code_fragment", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> addCodeFragment(@RequestParam() String id, @RequestPart("json") Map<String, Object> json, @RequestPart("file") MultipartFile file)
	{
		System.out.println("AddCodeFragment routing");
		try
		{
			createCodeFragmentFolder(id);
			createWriteJsonToDescription(json, fragmentsPath.resolve(id));
			extractTarFile(file, fragmentsPath.resolve(id));;
		}
		catch(CodeFragmentAlreadyExistsException e)
		{
			System.out.println("AddCodeFragment routing - Code fragment already exists: " + e.getMessage());
			return ResponseEntity.status(409).body(handleException(e));
		}
		catch(PathToCodeFragmentException | CodeFragmentFolderCreationException | WriteToDescriptionException | SrcTarExtractionException e)
		{
			System.out.println("AddCodeFragment routing - internal error: " + e.getMessage() + " " + e.getClass() + " " + e.getCause() + " handled: " + handleException(e));
			deleteDirectory(fragmentsPath.resolve(id).toFile());
			return ResponseEntity.status(500).body(handleException(e));
		}
		HashMap<String, Object> result = new HashMap<>();
		result.put("errorOccurred", false);
		System.out.println("AddCodeFragment routing success");
		return ResponseEntity.ok(result);
	}

	@PostMapping(value = "/add_plugin", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> addPlugin(@RequestParam() String id, @RequestPart("file") MultipartFile file)
	{
		System.out.println("add plugin routing");
		try
		{
			createPluginFolder(id);
			extractTarFile(file, pluginPath.resolve(id));
		}
		catch(CodeFragmentAlreadyExistsException e)
		{
			System.out.println("add plugin routing fail " + e.getMessage() + " " + e.getCause());
			return ResponseEntity.status(409).body(handleException(e));
		}
		catch(PathToCodeFragmentException | CodeFragmentFolderCreationException | SrcTarExtractionException e)
		{
			System.out.println("add plugin routing fail " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			deleteDirectory(pluginPath.resolve(id).toFile());
			return ResponseEntity.status(500).body(handleException(e));
		}
		HashMap<String, Object> result = new HashMap<>();
		result.put("errorOccurred", false);
		System.out.println("add plugin routing sucess");
		return ResponseEntity.ok(result);
	}

	@GetMapping(value = "/{className}/pluginProcedure", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getPluginProcedure(@PathVariable String className, @RequestParam() String type)
	{
		System.out.println("Code fragment " + className + " plugin Procedure for " + type + " routing");
		ResponseEntity<Map<String, Object>> list = getCodeFragments();
		List<String> codeFragments = (List<String>)(list.getBody().get("code_fragments"));
		if(!codeFragments.contains(className))
		{
			System.out.println("Code fragment " + className + " plugin Procedure for " + type + " routing fail. codeFragments does not contain className");
			return ResponseEntity.status(400).body(handleException(new UnknownCodeFragmentException("There is no such code_fragment in the system right now")));
		}

		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode result = objectMapper.createObjectNode();
		switch(type)
		{
			case(TYPE_EXE_START_C_PROCEDURE):
			{
				JsonNode body = objectMapper.valueToTree(getExeStartCProcedure(className));
				if(checkAndAddErrorsToResult(body, result))
				{
					System.out.println("internal error in checkAndAddErrors");
					return ResponseEntity.status(500).body(objectMapper.convertValue(body, Map.class));
				}
				System.out.println("Code fragment " + className + " plugin Procedure for " + type + " routing success");
				return ResponseEntity.ok(getExeStartCProcedure(className));
			}
			case(TYPE_LuNA):
			{
				System.out.println("idk what to do with luna yet");
				return ResponseEntity.ok(new HashMap<>());
			}
		}
		System.out.println("Code fragment " + className + " plugin Procedure for " + type + " routing: Unknown plugin requested (plugin code): " + type);
		return ResponseEntity.status(400).body(handleException(new UnknownRequestException("Unknown plugin requested. Internal plugin code requested: " + type)));
	}

	@GetMapping(value = "/{className}/target_code", produces = "application/x-tar")
	public @ResponseBody ResponseEntity<byte[]> getTargetCode(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " target code");
		ResponseEntity<Map<String, Object>> list = getCodeFragments();
		List<String> codeFragments = (List<String>)(list.getBody().get("code_fragments"));
		if(!codeFragments.contains(className))
		{
			System.out.println("There is no such code_fragment in the system right now");
			return ResponseEntity.status(400).body("There is no such code_fragment in the system right now".getBytes());
		}

		byte[] tarResult;
		try
		{
			tarResult = createTarFromPath(fragmentsPath.resolve(className).resolve(SOURCE_FOLDER));
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " target code error " + e.getMessage() + " " + e.getCause());
			return ResponseEntity.status(500).body(e.getMessage().getBytes());
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.setContentDispositionFormData("attachment", className + ".tar");
		System.out.println("Code fragment " + className + " target code sucess");
		return new ResponseEntity<>(tarResult, headers, HttpStatus.OK);
	}

/*
	private @ResponseBody Map<String, Object> getLuNAFunction(@PathVariable String className)
	{
		try
		{
			String classPath = className + "/" + "LuNAFunction.class";

			CodeFragment instance;
			String lunaFunction;
			String imp;
			String name;
			String cFunction;
			try
			{
				instance = getPluginInstance(classPath);
				lunaFunction = instance.getLuNAFunction();
				imp = instance.getLuNAFunctionImport();
				name = instance.getLuNAFunctionName();
				cFunction = instance.getLuNACFunction();
			}
			catch(NullPointerException e)
			{
				throw new NullPointerException("Method 'getLuNAFunction' is not supported by " + className + " code fragment");
			}

			if(lunaFunction == null || imp == null || name == null || cFunction == null)
			{
				throw new NullPointerException("Method 'getLuNAFunction' is not supported by " + className + " code fragment");
			}

			Map<String, Object> resultJson = new HashMap<>();
			resultJson.put("LuNA_function", lunaFunction);
			resultJson.put("C_function", cFunction);
			resultJson.put("name", name);
			resultJson.put("import", imp);
			resultJson.put("errorOccurred", false);
			return resultJson;
		}
		catch (Exception e)
		{
			return handlePluginException(e);
		}
	}
*/
/*
	@GetMapping("/{className}/Make")
	public @ResponseBody Map<String, Object> getMake(@PathVariable String className)
	{
		try
		{
			String classPath = className + "/" + "Make.class";

			CodeFragment instance;
			String make;
			try
			{
				instance = getPluginInstance(classPath);
				make = instance.getMake();
			}
			catch(NullPointerException e)
			{
				throw new NullPointerException("Method 'getMake' is not supported by " + className + " code fragment");
			}

			if(make == null)
			{
				throw new NullPointerException("Method 'getMake' is not supported by " + className + " code fragment");
			}

			Map<String, Object> resultJson = new HashMap<>();
			resultJson.put("makeFile", make);
			resultJson.put("errorOccurred", false);
			return resultJson;
		}
		catch (Exception e)
		{
			return handlePluginException(e);
		}
	}
*/

	private @ResponseBody Map<String, Object> getExeStartCProcedure(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getExeStartCProcedure");
		try
		{
			List<String> list = loadAndRunPlugin(className, "ExeStartCProcedure");
			Map<String, Object> result = new HashMap<>();
			result.put("name", list.get(0));
			result.put("procedure", list.get(2));
			result.put("include", list.get(1));
			result.put("errorOccurred", false);
			System.out.println("Code fragment " + className + " getExeStartCProcedure sucess");
			return result;
		}
		catch (Exception e)
		{
			System.out.println("Code fragment " + className + " getExeStartCProcedure failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getImplementedMethods(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getImplementedMethods");
		Map<String, Object> temp = getSpecific(className, "IMPLEMENTED_PLUGINS");
		Map<String, Object> result = new HashMap<>();
		result.put("implemented_methods", ((String)temp.get("IMPLEMENTED_PLUGINS")).split(";"));
		result.put("errorOccurred", temp.get("errorOccurred"));
		if((Boolean) temp.get("errorOccurred"))
		{
			result.put("errorCode", temp.get("errorCode"));
			result.put("errorMessage", temp.get("errorMessage"));
			System.out.println("Code fragment " + className + " getImplementedMethods errorMessage true:" + temp.get("errorMessage") + " " + temp.get("errorCode"));
		}
		System.out.println("Code fragment " + className + " getImplementedMethods success");
		return result;
	}

	private @ResponseBody Map<String, Object> getName(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getName");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "NAME");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find NAME in description file");
			}

			Map<String, Object> result = new HashMap<>();
			result.put("name", descriptionValue);
			result.put("errorOccurred", false);
			System.out.println("Code fragment " + className + " getName success");
			return result;
		}
		catch (Exception e)
		{
			System.out.println("Code fragment " + className + " getName failure " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getModuleDescription(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getModuleDescription");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "DESCRIPTION");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find DESCRIPTION in description file");
			}

			Map<String, Object> result = new HashMap<>();
			result.put("description", descriptionValue);
			result.put("errorOccurred", false);
			System.out.println("Code fragment " + className + " getModuleDescription sucess");
			return result;
		}
		catch (Exception e)
		{
			System.out.println("Code fragment " + className + " getModuleDescription failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getInputVarCount(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getInputVarCount");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "INPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find INPUT_VAR_COUNT in description file");
			}

			Map<String, Object> result = new HashMap<>();
			result.put("input_var_count", descriptionValue);
			result.put("errorOccurred", false);
			System.out.println("Code fragment " + className + " getInputVarCount success");
			return result;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getInputVarCount failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getInputVarDescriptions(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getInputVarDescriptions");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "INPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find INPUT_VAR_COUNT in description file");
			}

			int varCount = Integer.parseInt(descriptionValue);
			Map<String, Object> resultJson = new HashMap<>();
			ArrayList<String> result = new ArrayList<>();
			for(int i = 1; i < varCount + 1; i++)
			{
				String value = getDescriptionTXTValue(reader, "IVAR" + i);
				if(value == null)
				{
					throw new InvalidDescriptionFormatException("Can't find IVAR" + i + " in description file");
				}
				result.add(value);
			}
			resultJson.put("errorOccurred", false);
			resultJson.put("input_descriptions", result);
			System.out.println("Code fragment " + className + " getInputVarDescriptions success");
			return resultJson;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getInputVarDescriptions failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getOutputVarCount(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getOutputVarCount");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "OUTPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find OUTPUT_VAR_COUNT in description file");
			}

			Map<String, Object> result = new HashMap<>();
			result.put("output_var_count", descriptionValue);
			result.put("errorOccurred", false);
			System.out.println("Code fragment " + className + " getOutputVarCount sucess");
			return result;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getOutputVarCount failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getOutputVarDescriptions(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getOutputVarDescriptions");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "OUTPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find OUTPUT_VAR_COUNT in description file");
			}

			int varCount = Integer.parseInt(descriptionValue);
			Map<String, Object> resultJson = new HashMap<>();
			ArrayList<String> result = new ArrayList<>();
			for(int i = 1; i < varCount + 1; i++)
			{
				String value = getDescriptionTXTValue(reader, "OVAR" + i);
				if(value == null)
				{
					throw new InvalidDescriptionFormatException("Can't find OVAR" + i + " in description file");
				}
				result.add(value);
			}
			resultJson.put("errorOccurred", false);
			resultJson.put("output_descriptions", result);
			System.out.println("Code fragment " + className + " getOutputVarDescriptions sucess");
			return resultJson;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getOutputVarDescriptions failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getInputVarTypes(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getInputVarTypes");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "INPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find INPUT_VAR_COUNT in description file");
			}

			int varCount = Integer.parseInt(descriptionValue);
			Map<String, Object> resultJson = new HashMap<>();
			ArrayList<String> result = new ArrayList<>();
			for(int i = 1; i < varCount + 1; i++)
			{
				String value = getDescriptionTXTValue(reader, "IVAR" + i + "_TYPE");
				if(value == null)
				{
					throw new InvalidDescriptionFormatException("Can't find IVAR" + i + "_TYPE in description file");
				}
				result.add(value);
			}
			resultJson.put("errorOccurred", false);
			resultJson.put("input_types", result);
			System.out.println("Code fragment " + className + " getInputVarTypes sucess");
			return resultJson;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getInputVarTypes failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getOutputVarTypesFull(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getOutputTypesFull");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "OUTPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find OUTPUT_VAR_COUNT in description file");
			}

			int varCount = Integer.parseInt(descriptionValue);
			Map<String, Object> resultJson = new HashMap<>();
			ArrayList<String> result = new ArrayList<>();
			for(int i = 1; i < varCount + 1; i++)
			{
				String value = getDescriptionTXTValue(reader, "OVAR" + i + "_TYPE");
				if(value == null)
				{
					throw new InvalidDescriptionFormatException("Can't find OVAR" + i + "_TYPE in description file");
				}
				result.add(value);
			}
			resultJson.put("errorOccurred", false);
			resultJson.put("output_types", result);
			System.out.println("Code fragment " + className + " getOutputTypesFull sucess");
			return resultJson;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getOutputTypesFull failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

	private @ResponseBody Map<String, Object> getOutputVarTypesLight(@PathVariable String className)
	{
		System.out.println("Code fragment " + className + " getOutputTypesLight");
		try
		{
			Path descriptionPath = fragmentsPath.resolve(className).resolve(DESCRIPTION_FILE);
			InputStream inputStream = Files.newInputStream(descriptionPath);

			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String descriptionValue = getDescriptionTXTValue(reader, "OUTPUT_VAR_COUNT");
			if(descriptionValue == null)
			{
				throw new InvalidDescriptionFormatException("Can't find OUTPUT_VAR_COUNT in description file");
			}

			int varCount = Integer.parseInt(descriptionValue);
			Map<String, Object> resultJson = new HashMap<>();
			ArrayList<String> result = new ArrayList<>();
			for(int i = 1; i < varCount + 1; i++)
			{
				String value = getDescriptionTXTValue(reader, "OVAR" + i + "_TYPE");
				if(value == null)
				{
					throw new InvalidDescriptionFormatException("Can't find OVAR" + i + "_TYPE in description file");
				}
				String toAdd = value.split(";")[0];
				result.add(toAdd);
			}
			resultJson.put("errorOccurred", false);
			resultJson.put("output_types", result);
			System.out.println("Code fragment " + className + " getOutputTypesLight success");
			return resultJson;
		}
		catch(Exception e)
		{
			System.out.println("Code fragment " + className + " getOutputTypesLight failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			return handleException(e);
		}
	}

/*
	private String convertInputTypesToCTypes(String types, int inputVarCount) throws IOException
	{
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(types);
		ObjectNode result = objectMapper.createObjectNode();
		if(checkAndAddErrorsToResult(jsonNode, result))
		{
			return result.toString();
		}
		for(int i  = 0; i < inputVarCount; i++)
		{
			String key = "ivar" + (i + 1) + "_type";
			String type = jsonNode.get(key).asText();
			switch(type)
			{
				case ("any_path"):
				case ("local_path"):
				{
					result.put(key, "const char*");
					break;
				}
				case ("int"):
				{
					result.put(key, "const int");
					break;
				}
			}
		}
		result.put("errorOccurred", false);
		return result.toString();
	}

	private String convertOutputTypesToCTypes(String types, int outputVarCount) throws IOException
	{
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(types);
		ObjectNode result = objectMapper.createObjectNode();
		if(checkAndAddErrorsToResult(jsonNode, result))
		{
			return result.toString();
		}
		for(int i  = 0; i < outputVarCount; i++)
		{
			String key = "ovar" + (i + 1) + "_type";
			String type = jsonNode.get(key).asText();
			switch(type)
			{
				case ("any_path"):
				case ("local_path"):
				{
					result.put(key, "char*");
					break;
				}
			}
		}
		result.put("errorOccurred", false);
		return result.toString();
	}
*/

	private List<String> loadAndRunPlugin(String className, String pluginName) throws WrongPluginFormat
	{
		System.out.println("Code fragment " + className + " loadAndRunPlugin");
		try
		{
			File file = pluginPath.resolve(pluginName).toFile();

			URL url = file.toURI().toURL();
			URL[] urls = new URL[]{url};
			ClassLoader cl = new URLClassLoader(urls, Thread.currentThread().getContextClassLoader());
			Class<?> cls = Class.forName("ExeStartCProcedure", true, cl);
			Object object = cls.getDeclaredConstructor().newInstance();

			Plugin plugin = null;
			if(object instanceof Plugin)
			{
				plugin = (Plugin) object;
			}
			if(plugin == null)
			{
				return new ArrayList<>();
			}
			System.out.println("Code fragment " + className + " loadAndRunPlugin sucess");
			return plugin.getResult(className, URL);
		}

		catch(NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException | ClassNotFoundException | IOException e)
		{
			System.out.println("Code fragment " + className + " loadAndRunPlugin failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new WrongPluginFormat(e.getMessage());
		}
    }

	private boolean checkAndAddErrorsToResult(JsonNode check, ObjectNode result)
	{
		System.out.println("checkAndAddErrorsToResult");
		if(check.get("errorOccurred").asBoolean())
		{
			result.put("errorOccurred", true);
			result.put("errorCode", check.get("errorCode").asBoolean());
			result.put("errorMessage", check.get("errorMessage").asBoolean());
			return true;
		}
		return false;
	}

	private String getDescriptionTXTValue(BufferedReader reader, String key) throws IOException, ArrayIndexOutOfBoundsException
	{
		String line;
		while((line = reader.readLine()) != null)
		{
			String[] lines = line.split(":");
			if(key.equals(lines[0]))
			{
				return lines[1];
			}
		}
		return null;
	}

	private Map<String, Object> handleException(Exception e)
	{
		Map<String, Object> resultJson = new HashMap<>();
		resultJson.put("errorOccurred", true);
		resultJson.put("errorMessage", e.getMessage());
        switch (e)
		{
            case C_procedurePluginAccessException cProcedurePluginAccessException -> resultJson.put("errorCode", 1);
            case DescriptionAccessException descriptionAccessException -> resultJson.put("errorCode", 2);
            case InvalidDescriptionFormatException invalidDescriptionFormatException -> resultJson.put("errorCode", 3);
            case PathToPluginFolderException pathToPluginFolderException -> resultJson.put("errorCode", 4);
            case TarFolderException tarFolderException -> resultJson.put("errorCode", 5);
            case WalkingCodeFragmentsFolderException walkingCodeFragmentsFolderException -> resultJson.put("errorCode", 6);
            case WalkingPluginFoldersException walkingPluginFoldersException -> resultJson.put("errorCode", 7);
            case UnknownPluginRequested unknownPluginRequested -> resultJson.put("errorCode", 8);
            case UnknownCodeFragmentException unknownCodeFragmentException -> resultJson.put("errorCode", 11);
            case UnknownCodeFragmentMethodException unknownCodeFragmentMethodException -> resultJson.put("errorCode", 10);
            case UnknownRequestException unknownRequestException -> resultJson.put("errorCode", 9);
            case WriteToDescriptionException writeToDescriptionException -> resultJson.put("errorCode", 12);
            case CodeFragmentAlreadyExistsException codeFragmentAlreadyExistsException -> resultJson.put("errorCode", 13);
            case PathToCodeFragmentException pathToCodeFragmentException -> resultJson.put("errorCode", 14);
            case CodeFragmentFolderCreationException codeFragmentFolderCreationException -> resultJson.put("errorCode", 15);
            case SrcTarExtractionException srcTarExtractionException -> resultJson.put("errorCode", 16);
            case CantFindSpecificValueException cantFindSpecificValueException -> resultJson.put("errorCode", 17);
            case WrongPluginFormat wrongPluginFormat -> resultJson.put("errorCode", 18);
            default -> resultJson.put("errorCode", 19);
        }
		return resultJson;
	}


	private byte[] createTarFromPath(Path path) throws TarFolderException
	{
		System.out.println("createTarFromPath " + path);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		TarArchiveOutputStream tarStream = new TarArchiveOutputStream(baos);
		try
		{
			Files.walkFileTree(path, EnumSet.noneOf(FileVisitOption.class), Integer.MAX_VALUE, new SimpleFileVisitor<>()
			{
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException
				{
					String relativePath = path.relativize(file).toString();
					TarArchiveEntry entry = new TarArchiveEntry(file.toFile(), "src/" + relativePath);
					tarStream.putArchiveEntry(entry);
					IOUtils.copy(Files.newInputStream(file), tarStream);
					tarStream.closeArchiveEntry();
					return FileVisitResult.CONTINUE;
				}

				@Override
				public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException
				{
					String relativePath = path.relativize(dir).toString();
					TarArchiveEntry entry = new TarArchiveEntry(dir.toFile(), "src/" + relativePath + "/");
					tarStream.putArchiveEntry(entry);
					tarStream.closeArchiveEntry();
					return FileVisitResult.CONTINUE;
				}
			});
		}
		catch(Exception e)
		{
			System.out.println("createTarFromFile failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new TarFolderException(e.getMessage());
		}
		System.out.println("createTarFromPath " + path + " success");
		return baos.toByteArray();
	}

	private void deleteDirectory(File directory)
	{
		System.out.println("deleteDirectory");
		try
		{
			if(directory == null)
			{
				return;
			}

			if (!directory.exists())
			{
				return;
			}

			File[] files = directory.listFiles();
			if (files != null)
			{
				for (File file : files)
				{
					if (file.isDirectory())
					{
						deleteDirectory(file);
					}
					else
					{
						file.delete();
					}
				}
			}
			directory.delete();
		}
		catch(Exception e)
		{
			System.out.println("deleteDirectory " + directory.getPath() + " failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
		}
	}

	private static boolean initFolders()
	{
		System.out.println("Folder initialization");
		if (!Files.exists(folderPath))
		{
			try
			{
				Files.createDirectories(pluginPath);
				Files.createDirectories(fragmentsPath);
				System.out.println("Folder initialisation successful");
			}
			catch (IOException e)
			{
				System.err.println("Failed folder initialisation: " + e.getMessage());
				return false;
			}
		}
		return true;
	}

	private void createCodeFragmentFolder(String id) throws PathToCodeFragmentException, CodeFragmentAlreadyExistsException, CodeFragmentFolderCreationException
	{
		System.out.println("createCodeFragmentFolder");
		if(!Files.exists(fragmentsPath))
		{
			throw new PathToCodeFragmentException("fragments folder not found");
		}
		try
		{
			Path newFolderPath = fragmentsPath.resolve(id);
			if(Files.exists(newFolderPath))
			{
				throw new CodeFragmentAlreadyExistsException("code fragment folder already exists");
			}
			Files.createDirectory(newFolderPath);
		}
		catch(IOException e)
		{
			System.out.println("createCodeFragmentFolder failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new CodeFragmentFolderCreationException(e.getMessage());
		}
	}

	private void createPluginFolder(String id) throws PathToCodeFragmentException, CodeFragmentAlreadyExistsException, CodeFragmentFolderCreationException
	{
		System.out.println("createPluginFolder");
		if(!Files.exists(pluginPath))
		{
			throw new PathToCodeFragmentException("plugin folder folder not found");
		}
		try
		{
			Path newFolderPath = pluginPath.resolve(id);
			if(Files.exists(newFolderPath))
			{
				throw new CodeFragmentAlreadyExistsException("This plugin: " + id + " folder already exists");
			}
			Files.createDirectory(newFolderPath);
		}
		catch(IOException e)
		{
			System.out.println("createPluginFolder failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new CodeFragmentFolderCreationException(e.getMessage());
		}
	}

	private void createWriteJsonToDescription(Map<String, Object> json, Path path) throws WriteToDescriptionException
	{
		System.out.println("writeJson to description");
		try(FileWriter fileWriter = new FileWriter(path.resolve(DESCRIPTION_FILE).toFile()))
		{
			for(Map.Entry<String, Object> entry : json.entrySet())
			{
				fileWriter.write(entry.getKey() + ":" + entry.getValue() + "\n");
			}
		}
		catch(IOException e)
		{
			System.out.println("createWriteJsonToDescription failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new WriteToDescriptionException(e.getMessage());
		}
	}

	private void extractTarFile(MultipartFile tar, Path destination) throws SrcTarExtractionException
	{
		System.out.println("extractTarFile");
		try (TarArchiveInputStream tais = new TarArchiveInputStream(new BufferedInputStream(tar.getInputStream())))
		{
			TarArchiveEntry entry;
			while ((entry = tais.getNextTarEntry()) != null)
			{
				if (entry.isDirectory())
				{
					Files.createDirectories(destination.resolve(entry.getName()));
				}
				else
				{
					File outputFile = new File(destination.toFile(), entry.getName());
					try (OutputStream outputStream = new FileOutputStream(outputFile))
					{
						byte[] buffer = new byte[4096];
						int bytesRead;
						while ((bytesRead = tais.read(buffer)) != -1)
						{
							outputStream.write(buffer, 0, bytesRead);
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			System.out.println("extractTarFile failure: " + e.getMessage() + " " + e.getCause() + " " + e.getClass());
			throw new SrcTarExtractionException(e.getMessage());
		}
	}
}

