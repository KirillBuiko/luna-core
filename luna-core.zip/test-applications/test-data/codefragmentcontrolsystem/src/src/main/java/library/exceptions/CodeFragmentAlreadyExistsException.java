package library.exceptions;

public class CodeFragmentAlreadyExistsException extends Exception
{
    public CodeFragmentAlreadyExistsException(String message)
    {
        super(message);
    }
}
