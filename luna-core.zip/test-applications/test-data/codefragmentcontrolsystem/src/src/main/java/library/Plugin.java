package library;

import java.util.List;

public interface Plugin
{
    public List<String> getResult(String id, String urlToControlSystem);
}
