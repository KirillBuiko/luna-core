package library.exceptions;

public class InvalidDescriptionFormatException extends Exception
{
    public InvalidDescriptionFormatException(String message)
    {
        super(message);
    }
}
